"use client";

import { useContextSelector } from "use-context-selector";
import { useSearchParams } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { ClientFetchDataContext } from "@/lib/providers/ClientFetchDataProvider";
import { AnimeType } from "@/types/Anime/Anime.type";

/*
 * Built-in player that takes videos from the AniLibria API (v1).
 * The anime is searched by its AniList titles, the episode number comes from the `?episode=` query parameter
 * (the episodes list in `AnimeInfo` changes it).
 * `selectedExtension` is reused as an optional AniLibria release alias (`?selectedExtension=sousou-no-frieren`).
 */

const HlsScriptUrl = "https://cdn.jsdelivr.net/npm/hls.js@1.5.7/dist/hls.min.js";
const DirectApiBase = "https://anilibria.top/api/v1";
const RememberedKeyPrefix = "anisun:anilibria:";
const QualityKeys = ["hls_1080", "hls_720", "hls_480"] as const;
const QualityLabels = {
    hls_1080: "1080p",
    hls_720:  "720p",
    hls_480:  "480p",
} as const;

type QualityKey = typeof QualityKeys[number];
type ApiAction = "search" | "release" | "episode";
type TimeRangeType = Partial<{ start: number; stop: number }>;
type EpisodeType = Partial<{
    id:         string;
    ordinal:    number;
    sort_order: number;
    hls_480:    string;
    hls_720:    string;
    hls_1080:   string;
    opening:    TimeRangeType;
    ending:     TimeRangeType;
}>;
type ReleaseType = Partial<{
    id:       number;
    alias:    string;
    year:     number;
    name:     Partial<{ main: string; english: string }>;
    episodes: Array<EpisodeType>;
}>;
type PageStatus = "searching" | "ready" | "empty" | "error";
type StreamStatus = "idle" | "loading" | "ready" | "error";
type HlsInstance = {
    loadSource:  (url: string) => void;
    attachMedia: (element: HTMLVideoElement) => void;
    destroy:     () => void;
    on:          (
        event: string,
        callback: (event: string, data: { fatal?: boolean; details?: string }) => void,
    ) => void;
};
type HlsConstructor = {
    new (configuration?: Record<string, unknown>): HlsInstance;
    isSupported: () => boolean;
    Events:      { ERROR: string };
};

function getApiPath(action: ApiAction, value: string): string {
    if (action === "search") {
        return `/app/search/releases?query=${encodeURIComponent(value)}`;
    }

    if (action === "release") {
        return `/anime/releases/${encodeURIComponent(value)}`;
    }

    return `/anime/releases/episodes/${encodeURIComponent(value)}`;
}

// first goes through our own server (no CORS problems), then tries the API directly from the browser
async function apiGet(action: ApiAction, value: string, signal: AbortSignal): Promise<unknown> {
    let proxied: Response | undefined;

    try {
        proxied = await fetch(
            `/api/anilibria?action=${action}&value=${encodeURIComponent(value)}`,
            { signal },
        );
    } catch {
        // our server is unreachable, try the API directly
    }

    if (proxied?.ok) {
        return proxied.json();
    }

    if (proxied?.status === 404) {
        throw new Error("not found");
    }

    const direct = await fetch(DirectApiBase + getApiPath(action, value), {
        signal,
        headers: { Accept: "application/json" },
    });

    if (!direct.ok) {
        throw new Error(`api status ${direct.status}`);
    }

    return direct.json();
}

function unwrapObject(json: unknown): Record<string, unknown> | undefined {
    if (typeof json !== "object" || json === null || Array.isArray(json)) {
        return;
    }

    const record = json as Record<string, unknown>;
    const inner = record.data;

    if (typeof inner === "object" && inner !== null && !Array.isArray(inner)) {
        return inner as Record<string, unknown>;
    }

    return record;
}

function unwrapList(json: unknown): Array<ReleaseType> {
    if (Array.isArray(json)) {
        return json as Array<ReleaseType>;
    }

    const inner = (json as { data?: unknown } | undefined)?.data;

    return Array.isArray(inner) ? (inner as Array<ReleaseType>) : [];
}

function isInside(time: number, range: TimeRangeType | undefined): boolean {
    return typeof range?.start === "number"
        && typeof range?.stop === "number"
        && time >= range.start
        && time < range.stop;
}

function readRemembered(animeId: number): string | undefined {
    try {
        return localStorage.getItem(RememberedKeyPrefix + animeId) ?? undefined;
    } catch {
        return;
    }
}

function writeRemembered(animeId: number, alias: string) {
    try {
        localStorage.setItem(RememberedKeyPrefix + animeId, alias);
    } catch {
        // storage can be disabled, it's not critical
    }
}

let hlsPromise: Promise<HlsConstructor | undefined> | undefined;

function getGlobalHls(): HlsConstructor | undefined {
    return (globalThis as unknown as { Hls?: HlsConstructor }).Hls;
}

// hls.js is loaded from a CDN only when the player is opened, so it doesn't weigh down the main bundle
function loadHls(): Promise<HlsConstructor | undefined> {
    const existing = getGlobalHls();

    if (existing) {
        return Promise.resolve(existing);
    }

    if (hlsPromise) {
        return hlsPromise;
    }

    hlsPromise = new Promise((resolve) => {
        const script = document.createElement("script");

        script.src = HlsScriptUrl;
        script.async = true;
        script.addEventListener("load", () => {
            resolve(getGlobalHls());
        });
        script.addEventListener("error", () => {
            hlsPromise = undefined;
            resolve(undefined);
        });
        document.head.append(script);
    });

    return hlsPromise;
}

export default function ExtensionsSelector({
    selectedExtension,
}: {
    selectedExtension: string;
}) {
    const data: Record<"Current", AnimeType> | undefined = useContextSelector(
        ClientFetchDataContext,
        (value) => value.data,
    );
    const searchParameters = useSearchParams();
    const episodeNumber = Math.max(1, Number(searchParameters.get("episode") ?? 1) || 1);
    const animeId = data?.Current?.idMal ?? data?.Current?.id ?? 0;
    const titleEnglish = data?.Current?.title?.english;
    const titleRomaji = data?.Current?.title?.romaji;
    const titlePreferred = data?.Current?.title?.userPreferred;

    const videoReference = useRef<HTMLVideoElement>(null);
    const resumeTimeReference = useRef(0);

    const [attempt, setAttempt] = useState(0);
    const [manualQuery, setManualQuery] = useState("");
    const [manualInput, setManualInput] = useState("");
    const [pageStatus, setPageStatus] = useState<PageStatus>("searching");
    const [results, setResults] = useState<Array<ReleaseType>>([]);
    const [selectedAlias, setSelectedAlias] = useState<string>();
    const [release, setRelease] = useState<ReleaseType>();
    const [releaseError, setReleaseError] = useState("");
    const [stream, setStream] = useState<EpisodeType>();
    const [streamStatus, setStreamStatus] = useState<StreamStatus>("idle");
    const [preferredQuality, setPreferredQuality] = useState<QualityKey>("hls_1080");
    const [playerMessage, setPlayerMessage] = useState("");
    const [skipRange, setSkipRange] = useState<"opening" | "ending">();

    const queries = useMemo(() => {
        const found: Array<string> = [];

        for (const entry of [titleEnglish, titleRomaji, titlePreferred]) {
            if (!entry) {
                continue;
            }

            found.push(entry);

            // "Title: Subtitle" -> "Title", helps when AniLibria names a season differently
            const shortTitle = entry.split(":")[0].trim();

            if (shortTitle.length > 3) {
                found.push(shortTitle);
            }
        }

        return [...new Set(found)].slice(0, 6);
    }, [titleEnglish, titleRomaji, titlePreferred]);
    const queriesKey = queries.join("|");

    // 1. search the anime on AniLibria
    useEffect(() => {
        const controller = new AbortController();
        const candidates = manualQuery.length > 0 ? [manualQuery] : queries;

        (async () => {
            setPageStatus("searching");

            try {
                for (const candidate of candidates) {
                    const json = await apiGet("search", candidate, controller.signal);
                    const found = unwrapList(json).filter((entry) => Boolean(entry?.alias));

                    if (found.length === 0) {
                        continue;
                    }

                    const remembered = readRemembered(animeId);
                    const rememberedAlias = found.find((entry) => entry.alias === remembered)?.alias;
                    const forcedAlias = selectedExtension.trim();

                    setResults(found);
                    setSelectedAlias(forcedAlias === "" ? (rememberedAlias ?? found[0].alias) : forcedAlias);
                    setPageStatus("ready");

                    return;
                }

                setResults([]);
                setPageStatus("empty");
            } catch {
                if (!controller.signal.aborted) {
                    setPageStatus("error");
                }
            }
        })();

        return () => {
            controller.abort();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [queriesKey, manualQuery, attempt, animeId, selectedExtension]);

    // 2. load the chosen release with its episodes
    useEffect(() => {
        if (selectedAlias === undefined) {
            return;
        }

        const controller = new AbortController();

        setRelease(undefined);
        setReleaseError("");

        (async () => {
            try {
                const json = await apiGet("release", selectedAlias, controller.signal);

                setRelease(unwrapObject(json) as ReleaseType | undefined);
            } catch {
                if (!controller.signal.aborted) {
                    setReleaseError("Не удалось загрузить релиз с AniLibria");
                }
            }
        })();

        return () => {
            controller.abort();
        };
    }, [selectedAlias]);

    const episodes = useMemo(() => {
        const list = [...(release?.episodes ?? [])];

        return list.sort((first, second) => {
            const firstIndex = first.ordinal ?? first.sort_order ?? 0;
            const secondIndex = second.ordinal ?? second.sort_order ?? 0;

            return firstIndex - secondIndex;
        });
    }, [release]);
    const currentEpisode = episodes.find((entry) => entry.ordinal === episodeNumber)
        ?? episodes[episodeNumber - 1];
    const episodeId = currentEpisode?.id;

    // 3. load fresh links of the current episode
    useEffect(() => {
        resumeTimeReference.current = 0;
        setSkipRange(undefined);

        if (episodeId === undefined) {
            setStream(undefined);
            setStreamStatus("idle");

            return;
        }

        const controller = new AbortController();

        setStreamStatus("loading");
        setPlayerMessage("");

        (async () => {
            try {
                const json = await apiGet("episode", episodeId, controller.signal);

                setStream(unwrapObject(json) as EpisodeType | undefined);
                setStreamStatus("ready");
            } catch {
                if (controller.signal.aborted) {
                    return;
                }

                // links from the release itself, if there are any
                if (currentEpisode?.hls_720 || currentEpisode?.hls_1080 || currentEpisode?.hls_480) {
                    setStream(currentEpisode);
                    setStreamStatus("ready");

                    return;
                }

                setStream(undefined);
                setStreamStatus("error");
            }
        })();

        return () => {
            controller.abort();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [episodeId]);

    const qualities = QualityKeys.filter((key) => Boolean(stream?.[key]));
    const activeQuality = qualities.includes(preferredQuality) ? preferredQuality : qualities[0];
    const sourceUrl = activeQuality ? stream?.[activeQuality] : undefined;

    // 4. attach the video to the player
    useEffect(() => {
        const video = videoReference.current;

        if (!video || sourceUrl === undefined) {
            return;
        }

        let hlsInstance: HlsInstance | undefined;
        let isNative = false;
        let cancelled = false;
        const startTime = resumeTimeReference.current;

        resumeTimeReference.current = 0;
        setPlayerMessage("");

        (async () => {
            const Hls = await loadHls();

            if (cancelled) {
                return;
            }

            if (Hls?.isSupported()) {
                hlsInstance = new Hls();
                hlsInstance.attachMedia(video);
                hlsInstance.loadSource(sourceUrl);
                hlsInstance.on(Hls.Events.ERROR, (_event, errorData) => {
                    if (errorData.fatal) {
                        setPlayerMessage(`Ошибка воспроизведения (${errorData.details ?? "unknown"})`);
                    }
                });
            } else if (video.canPlayType("application/vnd.apple.mpegurl") === "") {
                setPlayerMessage("Этот браузер не поддерживает воспроизведение HLS");

                return;
            } else {
                isNative = true;
                video.src = sourceUrl;
            }

            if (startTime > 0) {
                video.addEventListener("loadedmetadata", () => {
                    video.currentTime = startTime;
                }, { once: true });
            }
        })();

        return () => {
            cancelled = true;
            hlsInstance?.destroy();

            if (isNative) {
                video.removeAttribute("src");
                video.load();
            }
        };
    }, [sourceUrl]);

    function selectEpisode(number: number) {
        const modifiedParameters = new URLSearchParams(searchParameters);

        modifiedParameters.set("episode", number.toString());

        globalThis.history.replaceState({}, "", `?${modifiedParameters.toString()}`);
    }

    function handleTimeUpdate(event: React.SyntheticEvent<HTMLVideoElement>) {
        const time = event.currentTarget.currentTime;

        if (isInside(time, stream?.opening)) {
            setSkipRange("opening");

            return;
        }

        if (isInside(time, stream?.ending)) {
            setSkipRange("ending");

            return;
        }

        setSkipRange(undefined);
    }

    function handleSkip() {
        const video = videoReference.current;
        const range = skipRange === "opening" ? stream?.opening : stream?.ending;

        if (!video || typeof range?.stop !== "number") {
            return;
        }

        video.currentTime = range.stop;
    }

    function handleQuality(quality: QualityKey) {
        resumeTimeReference.current = videoReference.current?.currentTime ?? 0;

        setPreferredQuality(quality);
    }

    function handleSelectRelease(alias: string) {
        writeRemembered(animeId, alias);
        setSelectedAlias(alias);
    }

    function getOverlayText(): string {
        if (pageStatus === "searching") {
            return "Ищем аниме на AniLibria…";
        }

        if (pageStatus === "error") {
            return "Не удалось связаться с AniLibria";
        }

        if (pageStatus === "empty") {
            return "На AniLibria это аниме не нашлось. Попробуй поискать вручную ниже";
        }

        if (releaseError !== "") {
            return releaseError;
        }

        if (release === undefined) {
            return "Загружаем релиз…";
        }

        if (currentEpisode === undefined) {
            return `В этом релизе нет серии ${episodeNumber}`;
        }

        if (streamStatus === "loading") {
            return "Загружаем серию…";
        }

        if (streamStatus === "error" || sourceUrl === undefined) {
            return "Для этой серии нет видео";
        }

        return playerMessage;
    }

    const overlayText = getOverlayText();
    const hasPrevious = episodeNumber > 1;
    const hasNext = episodes.length > 0 && episodeNumber < episodes.length;
    const buttonClassName = "transition-[filter] cursor-pointer text-sm px-3 py-1.5 rounded-md bg-neutral-200 dark:bg-neutral-800 hover:brightness-90 disabled:opacity-40 disabled:cursor-default";

    return (
        <div className="flex flex-col w-full gap-2">
            <div className="relative w-full aspect-video bg-black sm:rounded-md overflow-clip">
                <video
                    ref={videoReference}
                    className="w-full h-full"
                    controls
                    playsInline
                    onTimeUpdate={handleTimeUpdate}
                    onEnded={() => {
                        if (hasNext) {
                            selectEpisode(episodeNumber + 1);
                        }
                    }}
                />
                {
                    overlayText !== "" && (
                        <div className="absolute inset-0 flex items-center justify-center p-4 text-center text-sm text-white bg-black/70">
                            <div className="flex flex-col items-center gap-3">
                                <p>{overlayText}</p>
                                {
                                    pageStatus === "error" && (
                                        <button
                                            className={buttonClassName}
                                            onClick={() => {
                                                setAttempt((previous) => previous + 1);
                                            }}
                                        >
                                            Повторить
                                        </button>
                                    )
                                }
                            </div>
                        </div>
                    )
                }
                {
                    skipRange !== undefined && (
                        <button
                            className="absolute right-3 bottom-16 cursor-pointer text-sm px-3 py-1.5 rounded-md bg-white/90 text-black hover:bg-white"
                            onClick={handleSkip}
                        >
                            {skipRange === "opening" ? "Пропустить опенинг" : "Пропустить эндинг"}
                        </button>
                    )
                }
            </div>
            <div className="flex flex-wrap items-center gap-2 px-2 sm:px-0">
                <button
                    className={buttonClassName}
                    disabled={!hasPrevious}
                    onClick={() => {
                        selectEpisode(episodeNumber - 1);
                    }}
                >
                    ← Назад
                </button>
                <span className="text-sm opacity-70">Серия {episodeNumber}</span>
                <button
                    className={buttonClassName}
                    disabled={!hasNext}
                    onClick={() => {
                        selectEpisode(episodeNumber + 1);
                    }}
                >
                    Дальше →
                </button>
                <div className="flex gap-2 ml-auto">
                    {
                        qualities.map((quality) => {
                            return (
                                <button
                                    key={quality}
                                    className={buttonClassName}
                                    disabled={quality === activeQuality}
                                    onClick={() => {
                                        handleQuality(quality);
                                    }}
                                >
                                    {QualityLabels[quality]}
                                </button>
                            );
                        })
                    }
                </div>
            </div>
            {
                results.length > 1 && (
                    <div className="flex flex-wrap items-center gap-2 px-2 sm:px-0">
                        <span className="text-sm opacity-70">Релиз:</span>
                        {
                            results.slice(0, 8).map((entry) => {
                                return (
                                    <button
                                        key={entry.alias}
                                        className={buttonClassName}
                                        disabled={entry.alias === selectedAlias}
                                        onClick={() => {
                                            handleSelectRelease(entry.alias ?? "");
                                        }}
                                    >
                                        {entry.name?.main ?? entry.alias}
                                        {entry.year ? ` (${entry.year})` : ""}
                                    </button>
                                );
                            })
                        }
                    </div>
                )
            }
            <div className="flex flex-wrap items-center gap-2 px-2 sm:px-0">
                <input
                    className="flex-1 min-w-40 text-sm px-3 py-1.5 rounded-md bg-neutral-200 dark:bg-neutral-800 outline-none"
                    placeholder="Другое название для поиска на AniLibria"
                    value={manualInput}
                    onChange={(event) => {
                        setManualInput(event.target.value);
                    }}
                    onKeyDown={(event) => {
                        if (event.key === "Enter") {
                            setManualQuery(manualInput.trim());
                        }
                    }}
                />
                <button
                    className={buttonClassName}
                    onClick={() => {
                        setManualQuery(manualInput.trim());
                    }}
                >
                    Искать
                </button>
            </div>
        </div>
    );
}
